<?php

namespace App\Imports;

use App\Raw;
use Exception;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Str;

class MachineImport implements ToModel
{
    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function model(array $row)
    {
        
        // dd($row['id']);
        if($row[0] != "ID" && $row[0] != "Personnel" && $row[0] != null && $row[0] != "Daily+Report"){

         Raw::updateOrCreate([
            'acc_id' => $row[0],

            'date'     => $row[5],
            'morning'  => 1,
            'afternoon' => 0],['name'   => $row[1] . ' ' . $row[2],
            'check_in' => $this->checkin($row[10], 0 ),
            'check_out' => $this->checkout($row[10], 0),
        ]);
        return Raw::updateOrCreate([
            'acc_id' => $row[0],

            'date'     => $row[5],
            'morning'  => 0,
            'afternoon' => 1],[ 'name'   => $row[1] . ' ' . $row[2],
            'check_in' => $this->checkin($row[10], 1 ),
            'check_out' => $this->checkout($row[10], 1),
        ]);
        ;
        }
        else{
            return null;
        }
    }

    public function get_morning($punch)
    {
        $var = explode(";", $punch);
        return $var[0];
    }

    public function get_afternoon($punch)
    {
        $var = explode(";", $punch);
        return count($var) == 2? $var[1] : "";
    }
    public function checkin($punch, $type)
    {


        $result = $type == 0? $this->get_morning($punch) : $this->get_afternoon($punch);

        $var = explode("-", $result);

        return $var[0];
    }
    public function checkout($punch, $type)
    {
        $result = $type == 0? $this->get_morning($punch) : $this->get_afternoon($punch);
        $var = explode("-", $result);
        
        return count($var) == 2? $var[1] : "";
    }

    public function format_time($time)
    {
        return date("H:i:s", strtotime($time));
    }

}
