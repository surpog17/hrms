<?php

namespace App\Imports;

use App\Employee;
use App\Webhr;
use App\WebhrLate;
use App\Merit;
use Exception;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class IncentiveImport implements ToModel, WithHeadingRow
{
    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function model(array $row)
    {
        try {
            $employees = Employee::where('acc_id', $row[Str::slug('acc_id', '_')])->first()->id;

            


            if (!$employees) {
                return null;
            }

            if (!Employee::where('acc_id', $row[Str::slug('acc_id', '_')])->first()) {
                return null;
            }
            if(!$this->get_merit_type($row[Str::slug('type', '_')])){
                return null;
            }
        } catch (Exception $e) {
            return null;
        }

        return Merit::Create([
            'employee_id' => Employee::where('acc_id', $row[Str::slug('acc_id', '_')])->first()->id,
            'date'     => date("Y-m-d"),
            'merit_type_id' => $this->get_merit_type($row[Str::slug('type', '_')]),
            'remark'     => $row[Str::slug('bonus', '_')],
              'amount_type'     => $row[Str::slug('amount_type', '_')]
        ]);
    }

    public function headingRow(): int
    {
        return 1;
    }

    public function format_date($date)
    {
        $time = strtotime($date);

        $newformat = date('Y-m-d', $time);

        return $newformat;
    }
    
    public function get_merit_type($type)
    {
        if($type==0){
            return 2;
        }elseif($type==1){
            return 4;
        }elseif($type==2){
            return 3;
        }elseif($type==3){
            return 5;
        }
        elseif($type==4){ 
            return 6;
        }
         elseif($type==5){
            return 9;
        }
          elseif($type==6){
            return 8;
        }
        
        
        else{
            return null;
        }
    }
}
