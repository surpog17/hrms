<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Medicalinsurance extends Model
{
    //
    protected $guarded = [];

   
}
