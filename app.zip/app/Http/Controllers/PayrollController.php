<?php

namespace App\Http\Controllers;

use App\Award;
use App\Deduct;
use App\Employee;
use App\Exports\BanksExport;
use App\Exports\PayrollsExport;
use App\Payroll;
use App\Webhr;
use Barryvdh\DomPDF\Facade as PDF;
use DB;
use Illuminate\Http\Request;
use Mail;
use Maatwebsite\Excel\Facades\Excel;
//
class PayrollController extends Controller
{
    //
    public function index()
    {
        $employee = Employee::where([['is_active', 1],['basic_salary','!=',null]])->get();
        Payroll::truncate();
        foreach ($employee as $emp) {
            $payroll = new Payroll;
            $payroll->employee_id = $emp->id;
            $payroll->save();
        }

        return $this->allowance();
    }
    public function allowance()
    {

        $payroll = Payroll::all();


        foreach ($payroll as $pay) {
            $emp = Employee::find($pay->employee_id);
            if ($emp == NULL) { } else {
                $pay->trans_allowance = ($emp->basic_salary) * 0.15;
                $pay->gross_salary = ((($emp->basic_salary) * 0.15) + $emp->basic_salary);
                $pay->save();
            }
        }


        return $this->totalaward();
    }

    public function totalaward()
    {
        $payroll = Payroll::all();


        foreach ($payroll as $pay) {
            $totalaward = Award::where('employee_id', $pay->employee_id)->first();
            if ($totalaward == NULL) { } else {
                $pay->total_award = ($totalaward->ieb) + ($totalaward->allowance) + ($totalaward->eodb) + ($totalaward->cdb) + ($totalaward->mpeqb) + ($totalaward->speqb) + ($totalaward->tvcqb) + ($totalaward->bepeqb) + ($totalaward->fhaqb) + ($totalaward->tpcqb) + ($totalaward->exam_bonus) + ($totalaward->bonus);
                $pay->save();
            }
        }

        return $this->tax_trans();
    }

    public function tax_trans()
    {
        $payroll = Payroll::all();

        foreach ($payroll as $pay) {

            if (($pay->trans_allowance) > 600) {
                $pay->tax_tran_allowance = (($pay->trans_allowance) - 600);
                $pay->save();
            } else {
                $pay->tax_tran_allowance = 0;
                $pay->save();
            }
        }
        return $this->emp_pension();
    }

    public function emp_pension()
    {
        $payroll = Payroll::all();

        foreach ($payroll as $pay) {
            $ded = Deduct::where('employee_id', $pay->employee_id)->first();
            $dedvalues = 0;
            if($ded){
                $dedvalues = $ded->absent;
            }
            $emp = Employee::find($pay->employee_id);
            if ($emp == NUll or ($emp->probation == 1) or (($emp->basic_salary) < ($dedvalues + 1000))) { } else {
                $pay->emp_pension = (($emp->basic_salary-$dedvalues) * 0.07);
                $pay->comp_pension = (($emp->basic_salary-$dedvalues) * 0.11);
                $pay->save();
            }
        }
        return $this->taxable_income();
    }

    public function taxable_income()
    {
        $payroll = Payroll::all();

        foreach ($payroll as $pay) {

            $emp = Employee::find($pay->employee_id);
            $ded = Deduct::where('employee_id', $pay->employee_id)->first();
            if ($emp == NUll) { } else {
                $pay->taxable_income = (($emp->basic_salary) + ($pay->total_award) + ($pay->tax_tran_allowance));
                $pay->save();
                if ($ded == NUll) { } else {
                    if((($pay->taxable_income) - ($ded->absent))<0){
                        $pay->taxable_income = 0;
                        $pay->save();
                    }else{
                        $pay->taxable_income = (($pay->taxable_income) - ($ded->absent));
                        $pay->save();
                    }
                }
            }
        }
        return $this->tax();
    }

    public function tax()
    {
        $payroll = Payroll::all();


        foreach ($payroll as $pay) {
            $taxable = $pay->taxable_income;

            if ($taxable < 600) {
                $pay->tax = 0;
                $pay->save();
            } elseif ($taxable <= 1650 and $taxable > 600) {
                $pay->tax = ($taxable * 0.1) - 60;
                $pay->save();
            } elseif ($taxable <= 3200 and $taxable > 1650) {
                $pay->tax = ($taxable * 0.15) - 142.5;
                $pay->save();
            } elseif ($taxable <= 5250 and $taxable > 3200) {
                $pay->tax = ($taxable * 0.2) - 302.5;
                $pay->save();
            } elseif ($taxable <= 7800 and $taxable > 5250) {
                $pay->tax = ($taxable * 0.25) - 565;
                $pay->save();
            } elseif ($taxable <= 10900 and $taxable > 7800) {
                $pay->tax = ($taxable * 0.30) - 955;
                $pay->save();
            } elseif ($taxable > 10900) {
                $pay->tax = ($taxable * 0.35) - 1500;
                $pay->save();
            }
        }

        return $this->total_deduction();
    }
    public function total_deduction()
    {
        $payroll = Payroll::all();

        foreach ($payroll as $pay) {

            $ded = Deduct::where('employee_id', $pay->employee_id)->first();

            if ($ded == NUll) {
                $pay->total_deduction = (($pay->tax) + ($pay->emp_pension));
                $pay->save();
            } else {
                $pay->total_deduction = (($pay->tax) + ($ded->absent) + ($ded->other)+ ($ded->exam) + ($ded->latecommer) + ($ded->pma) + ($ded->car) + ($ded->medical) + ($ded->loan) + ($pay->emp_pension));
                $pay->save();
            }
        }
        return $this->gross();
    }

    public function gross()
    {
        $payroll = Payroll::all();

        foreach ($payroll as $pay) {
            $emp = Employee::find($pay->employee_id);
            if ($emp == NULL) { } else {
                $pay->gross_income = (($pay->total_award) + ($pay->trans_allowance) + ($emp->basic_salary));
                $pay->save();
            }
        }
        return $this->net();
    }

    public function net()
    {
        $payroll = Payroll::all();

        foreach ($payroll as $pay) {
            $pay->net_income = (($pay->gross_income) - ($pay->total_deduction));
            $pay->save();
        }
        return $this->view();
    }

    public function view()
    {
        $payroll = Payroll::orderBy('employee_id')->get();
        $emp = Employee::all();
        return view('payroll')->with('payroll', $payroll)->with('emp', $emp);
    }

    public function bank_view()
    {
        $bank = Banks::orderBy('employee_id')->get();
        $payroll = Payroll::all();
        return view('view_bank')->with('payroll', $payroll)->with('bank', $bank);
    }

    public function export_excel()
    {
        return Excel::download(new PayrollsExport, 'IEPayroll.xlsx');
    }

    public function export_bank()
    {
        return Excel::download(new BanksExport, 'Bank.xlsx');
    }
    public function email()
    {
        $payroll = Payroll::all();


        foreach ($payroll as $pay) {
            $webhr = Webhr::where('acc_id', $pay->employee->acc_id)->first();
            if ($webhr){
               // if ($webhr->acc_id == 192) {
                    if($webhr->email){
                    # code...
                    $ded = Deduct::where('employee_id', $pay->employee_id)->first();
                    $award = Award::where('employee_id', $pay->employee_id)->first();
                    $employee = Employee::find($pay->employee_id);

                    $data = array(
                        'id' => $webhr->acc_id,
                        'email' => $webhr->email,
                        'name' => $webhr->full_name,
                    );

                    // $customPaper = array(0,0,567.00,283.80);
                    $pdf = PDF::loadView('paysliptemplate', compact('webhr', 'pay', 'award', 'ded', 'employee'));



                    // Mail::to($user->email)->send(new payroll_mail($user));
                    // Mail::send('emails.payroll', ["pass_data" => $data], function ($message) use ($pdf, $webhr) {
                    //     $message->from('iefinance@ienetworksolutions.com', 'IEFinanceNoReply@ienetworksolutions.com');

                    //     //$message->to($webhr->email)->cc('iefinance@ienetworksolutions.com')->subject('Generated Payroll');
                    //      $message->to('hawi@ienetworks.co')->subject('Generated Payroll');

                    //     $message->attachData($pdf->output(), "IE-payroll.pdf");
                    // });
                   // }

                }
            }
        }

        // Mail::to(Auth::user()->email)->send(new Payroll());
        // return redirect('/');

        return redirect('/home');
    }
    
    public function personalemail($id)
    {
        $payroll = Payroll::where('id', $id)->get();

        foreach ($payroll as $pay) {
            $webhr = Webhr::where('acc_id', $pay->employee->acc_id)->first();
            if ($webhr == null) { } else {
                if ($webhr->acc_id == $pay->employee->acc_id) {
                    if($webhr->email){
                    # code...
                    $ded = Deduct::where('employee_id', $pay->employee_id)->first();
                    $award = Award::where('employee_id', $pay->employee_id)->first();
                    $employee = Employee::find($pay->employee_id);

                    $data = array(
                        'id' => $webhr->acc_id,
                        'email' => $webhr->email,
                        'name' => $webhr->full_name,
                    );

                    // $customPaper = array(0,0,567.00,283.80);
                    $pdf = PDF::loadView('paysliptemplate', compact('webhr', 'pay', 'award', 'ded', 'employee'));



                    // Mail::to($user->email)->send(new payroll_mail($user));
                    Mail::send('emails.payroll', ["pass_data" => $data], function ($message) use ($pdf, $webhr) {
                        $message->from('iefinance@ienetworksolutions.com', 'IEFinanceNoReply@ienetworksolutions.com');

                        $message->to($webhr->email)->cc('iefinance@ienetworksolutions.com')->subject('Generated Payroll');
                     

                        $message->attachData($pdf->output(), "IE-payroll.pdf");
                    });
                    }

                }
            }
        }

        // Mail::to(Auth::user()->email)->send(new Payroll());
        // return redirect('/');

        return redirect()->back();
    }
}
