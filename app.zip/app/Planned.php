<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Planned extends Model
{
    //
}
