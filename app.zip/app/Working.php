<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Working extends Model
{
    //
    protected $fillable = ['working'];
}
